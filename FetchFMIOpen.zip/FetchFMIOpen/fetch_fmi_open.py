# -*- coding: utf-8 -*-

"""
/***************************************************************************
 FetchFMIOpen
                                 A QGIS plugin
 A plugin to fetch observation data from FMI Open Data archive
                              -------------------
        begin                : 2017-08-16
        git sha              : $Format:%H$
        copyright            : (C) 2018 by Tero Niemi & Teemu Kokkonen
                               Aalto University School of Engineering
        email                : firstname.lastname@aalto.fi
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
from PyQt4.QtCore import QSettings, QTranslator, qVersion, QCoreApplication
from PyQt4.QtGui import QAction, QIcon, QMessageBox, QFileDialog
# # Initialize Qt resources from file resources.py
import resources
# Import the code for the dialog
from fetch_fmi_open_dialog import FetchFMIOpenDialog
import os.path

import datetime as dt
import urllib
import urllib2

# Import etree
import xml.etree.ElementTree as ET


class FetchFMIOpen:
    """QGIS Plugin Implementation."""

    def dataTypeChanged(self, i):
        if i == 0:
            self.dlg.groupBoxDaily.setEnabled(True)
            self.dlg.groupBoxWeather.setEnabled(False)
            self.dlg.groupBoxMonthly.setEnabled(False)
            self.dlg.groupBoxRadiation.setEnabled(False)
            self.dlg.groupBoxSoil.setEnabled(False)
            self.dlg.groupBoxSeaWaterLevel.setEnabled(False)
            self.dlg.groupBoxSea.setEnabled(False)
            self.dlg.groupBoxRoad.setEnabled(False)
        elif i == 1:
            self.dlg.groupBoxDaily.setEnabled(False)
            self.dlg.groupBoxWeather.setEnabled(True)
            self.dlg.groupBoxMonthly.setEnabled(False)
            self.dlg.groupBoxRadiation.setEnabled(False)
            self.dlg.groupBoxSoil.setEnabled(False)
            self.dlg.groupBoxSeaWaterLevel.setEnabled(False)
            self.dlg.groupBoxSea.setEnabled(False)
            self.dlg.groupBoxRoad.setEnabled(False)
        elif i == 2:
            self.dlg.groupBoxDaily.setEnabled(False)
            self.dlg.groupBoxWeather.setEnabled(False)
            self.dlg.groupBoxMonthly.setEnabled(True)
            self.dlg.groupBoxRadiation.setEnabled(False)
            self.dlg.groupBoxSoil.setEnabled(False)
            self.dlg.groupBoxSeaWaterLevel.setEnabled(False)
            self.dlg.groupBoxSea.setEnabled(False)
            self.dlg.groupBoxRoad.setEnabled(False)
        elif i == 3:
            self.dlg.groupBoxDaily.setEnabled(False)
            self.dlg.groupBoxWeather.setEnabled(False)
            self.dlg.groupBoxMonthly.setEnabled(False)
            self.dlg.groupBoxRadiation.setEnabled(True)
            self.dlg.groupBoxSoil.setEnabled(False)
            self.dlg.groupBoxSeaWaterLevel.setEnabled(False)
            self.dlg.groupBoxSea.setEnabled(False)
            self.dlg.groupBoxRoad.setEnabled(False)
        elif i == 4:
            self.dlg.groupBoxDaily.setEnabled(False)
            self.dlg.groupBoxWeather.setEnabled(False)
            self.dlg.groupBoxMonthly.setEnabled(False)
            self.dlg.groupBoxRadiation.setEnabled(False)
            self.dlg.groupBoxSoil.setEnabled(True)
            self.dlg.groupBoxSeaWaterLevel.setEnabled(False)
            self.dlg.groupBoxSea.setEnabled(False)
            self.dlg.groupBoxRoad.setEnabled(False)
        elif i == 5:
            self.dlg.groupBoxDaily.setEnabled(False)
            self.dlg.groupBoxWeather.setEnabled(False)
            self.dlg.groupBoxMonthly.setEnabled(False)
            self.dlg.groupBoxRadiation.setEnabled(False)
            self.dlg.groupBoxSoil.setEnabled(False)
            self.dlg.groupBoxSeaWaterLevel.setEnabled(True)
            self.dlg.groupBoxSea.setEnabled(False)
            self.dlg.groupBoxRoad.setEnabled(False)
        elif i == 6:
            self.dlg.groupBoxDaily.setEnabled(False)
            self.dlg.groupBoxWeather.setEnabled(False)
            self.dlg.groupBoxMonthly.setEnabled(False)
            self.dlg.groupBoxRadiation.setEnabled(False)
            self.dlg.groupBoxSoil.setEnabled(False)
            self.dlg.groupBoxSeaWaterLevel.setEnabled(False)
            self.dlg.groupBoxSea.setEnabled(True)
            self.dlg.groupBoxRoad.setEnabled(False)
        else:
            self.dlg.groupBoxDaily.setEnabled(False)
            self.dlg.groupBoxWeather.setEnabled(False)
            self.dlg.groupBoxMonthly.setEnabled(False)
            self.dlg.groupBoxRadiation.setEnabled(False)
            self.dlg.groupBoxSoil.setEnabled(False)
            self.dlg.groupBoxSeaWaterLevel.setEnabled(False)
            self.dlg.groupBoxSea.setEnabled(False)
            self.dlg.groupBoxRoad.setEnabled(True)


    def timeStepChanged(self, i):
        return

    def populateVarListDaily(self, varListDay):
        if self.dlg.cBoxDayPrecip.isChecked() is True:
            varListDay.append(0)
        if self.dlg.cBoxDayMeanT.isChecked() is True:
            varListDay.append(1)
        if self.dlg.cBoxDayMinT.isChecked() is True:
            varListDay.append(2)
        if self.dlg.cBoxDayMaxT.isChecked() is True:
            varListDay.append(3)
        if self.dlg.cBoxDaySnow.isChecked() is True:
            varListDay.append(4)
        if self.dlg.cBoxDayGroundMinT.isChecked() is True:
            varListDay.append(5)

    def populateVarListWeather(self, varListWeather):
        if self.dlg.cBoxWeaPrecip1h.isChecked() is True:
            varListWeather.append(0)
        if self.dlg.cBoxWeaPrecipInt.isChecked() is True:
            varListWeather.append(1)
        if self.dlg.cBoxWeaTemp.isChecked() is True:
            varListWeather.append(2)
        if self.dlg.cBoxWeaWind.isChecked() is True:
            varListWeather.append(3)
        if self.dlg.cBoxWeaWindDir.isChecked() is True:
            varListWeather.append(4)
        if self.dlg.cBoxWeaGust.isChecked() is True:
            varListWeather.append(5)
        if self.dlg.cBoxWeaRH.isChecked() is True:
            varListWeather.append(6)
        if self.dlg.cBoxWeaDew.isChecked() is True:
            varListWeather.append(7)
        if self.dlg.cBoxWeaAir.isChecked() is True:
            varListWeather.append(8)
        if self.dlg.cBoxWeaSnow.isChecked() is True:
            varListWeather.append(9)
        if self.dlg.cBoxWeaCloud.isChecked() is True:
            varListWeather.append(10)
        if self.dlg.cBoxWeaVis.isChecked() is True:
            varListWeather.append(11)

    def populateVarListMonthly(self, varListMonthly):
        if self.dlg.cBoxRRMon.isChecked() is True:
            varListMonthly.append(0)
        if self.dlg.cBoxTMon.isChecked() is True:
            varListMonthly.append(1)

    def populateVarListRadiation(self, varListRadiation):
        if self.dlg.cBoxGlobR.isChecked() is True:
            varListRadiation.append(0)
        if self.dlg.cBoxLWIn.isChecked() is True:
            varListRadiation.append(1)
        if self.dlg.cBoxLWOut.isChecked() is True:
            varListRadiation.append(2)
        if self.dlg.cBoxNetR.isChecked() is True:
            varListRadiation.append(3)
        if self.dlg.cBoxRadDir.isChecked() is True:
            varListRadiation.append(4)
        if self.dlg.cBoxRadRef.isChecked() is True:
            varListRadiation.append(5)
        if self.dlg.cBoxRadSun.isChecked() is True:
            varListRadiation.append(6)
        if self.dlg.cBoxRadDiff.isChecked() is True:
            varListRadiation.append(7)

    def populateVarListSoil(self, varListSoil):
        if self.dlg.cBoxSoilT.isChecked() is True:
            varListSoil.append(0)
        if self.dlg.cBoxSoilHum.isChecked() is True:
            varListSoil.append(1)

    def populateVarListSealevel(self, varListSealevel):
        if self.dlg.cBoxWatlevel.isChecked() is True:
            varListSealevel.append(0)

    def populateVarListSea(self, varListSea):
        if self.dlg.cBoxSeaT.isChecked() is True:
            varListSea.append(0)
        if self.dlg.cBoxSeaWave.isChecked() is True:
            varListSea.append(1)
        if self.dlg.cBoxSeaDir.isChecked() is True:
            varListSea.append(2)
        if self.dlg.cBoxSeaDev.isChecked() is True:
            varListSea.append(3)
        if self.dlg.cBoxSeaMod.isChecked() is True:
            varListSea.append(4)

    def populateVarListRoad(self, varListRoad):
        if self.dlg.cBoxAirTemp.isChecked() is True:
            varListRoad.append(0)
        if self.dlg.cBoxAirTempChange.isChecked() is True:
            varListRoad.append(1)
        if self.dlg.cBoxPrecipAmount.isChecked() is True:
            varListRoad.append(2)
        if self.dlg.cBoxPrecipAmount1d.isChecked() is True:
            varListRoad.append(3)
        if self.dlg.cBoxPrecipInt.isChecked() is True:
            varListRoad.append(4)
        if self.dlg.cBoxPrecipState.isChecked() is True:
            varListRoad.append(5)
        if self.dlg.cBoxPrecipCloud.isChecked() is True:
            varListRoad.append(6)
        if self.dlg.cBoxFreezeTemp.isChecked() is True:
            varListRoad.append(7)
        if self.dlg.cBoxRelHumid.isChecked() is True:
            varListRoad.append(8)
        if self.dlg.cBoxDewTemp.isChecked() is True:
            varListRoad.append(9)
        if self.dlg.cBoxDewDiff.isChecked() is True:
            varListRoad.append(10)
        if self.dlg.cBoxAirPressure.isChecked() is True:
            varListRoad.append(11)
        if self.dlg.cBoxPressTend.isChecked() is True:
            varListRoad.append(12)
        if self.dlg.cBoxWindSpeed.isChecked() is True:
            varListRoad.append(13)
        if self.dlg.cBoxWindDir.isChecked() is True:
            varListRoad.append(14)
        if self.dlg.cBoxGustSpeed.isChecked() is True:
            varListRoad.append(15)
        if self.dlg.cBoxVis.isChecked() is True:
            varListRoad.append(16)
        if self.dlg.cBoxPresentWea.isChecked() is True:
            varListRoad.append(17)
        if self.dlg.cBoxRoadTemp.isChecked() is True:
            varListRoad.append(18)
        if self.dlg.cBoxRoadTempChng.isChecked() is True:
            varListRoad.append(19)
        if self.dlg.cBoxRoadGroundTemp.isChecked() is True:
            varListRoad.append(20)
        if self.dlg.cBoxRoadConduc.isChecked() is True:
            varListRoad.append(21)
        if self.dlg.cBoxRoadSignal.isChecked() is True:
            varListRoad.append(22)
        if self.dlg.cBoxRoadIceFreq.isChecked() is True:
            varListRoad.append(23)
        if self.dlg.cBoxRoadFriction.isChecked() is True:
            varListRoad.append(24)
        if self.dlg.cBoxRoadWater.isChecked() is True:
            varListRoad.append(25)
        if self.dlg.cBoxRoadSnow.isChecked() is True:
            varListRoad.append(26)
        if self.dlg.cBoxRoadIce.isChecked() is True:
            varListRoad.append(27)
        if self.dlg.cBoxRoadMoist.isChecked() is True:
            varListRoad.append(28)
        if self.dlg.cBoxSaltAmount.isChecked() is True:
            varListRoad.append(29)
        if self.dlg.cBoxRoadSaltConc.isChecked() is True:
            varListRoad.append(30)


    def divideDuration(self, start, end, period_in_days):
        intervalBreak = []
        intervalBreak.append(start)
        while True:
            intervalBreak.append(intervalBreak[-1] +
                                 dt.timedelta(days=period_in_days))
            if intervalBreak[-1] + dt.timedelta(seconds=10) > end:
                intervalBreak[-1] = end
                break
        return intervalBreak

    def getData(self, dataURL, first):
        nsm = {"wml2": "http://www.opengis.net/waterml/2.0",
               "wfs": "http://www.opengis.net/wfs/2.0",
               "om": "http://www.opengis.net/om/2.0",
               "xlink": "http://www.w3.org/1999/xlink"
               }
        try:
            # DEBUG  Print the data query to Python console in QGIS
            # print(dataURL)
            conts = urllib2.urlopen(dataURL)
        except urllib2.HTTPError as e:
            if (e.code == 400):     # Bad request syntax error
                # Try to read the reason from xml structure
                errorXML = e.read()
                root = ET.fromstring(errorXML)
                # TJN: Not sure if the error is always here...
                reportText = root[0][0].text
            else:   # Other errors
                # Just show the web page contents
                reportText = urllib.urlopen(dataURL).read()
            raise ValueError(reportText)
        else:   # Everything is fine
            contents = conts.read()
            root = ET.fromstring(contents)
            WFSMembers = root.findall(".//wfs:member", namespaces=nsm)
            if (len(WFSMembers) == 0):
                return ''
            timeList = []
            valueList = []
            labelList = []
            for element in WFSMembers:
                timeList.append([])
                valueList.append([])
                obsPropNode = element.find(".//om:observedProperty",
                                           namespaces=nsm)
                obsPropURL = obsPropNode.get(
                            "{http://www.w3.org/1999/xlink}href")
                obsPropcontents = urllib2.urlopen(obsPropURL).read()
                obsPropRoot = ET.fromstring(obsPropcontents)
                labelNode = obsPropRoot.find(
                    "{http://inspire.ec.europa.eu/schemas/omop/2.9}label")
                labelList.append(labelNode.text)
                measurements = element.findall(".//wml2:MeasurementTVP",
                                               namespaces=nsm)
                for record in measurements:
                    timeList[-1].append(record.find("wml2:time",
                                                    namespaces=nsm).text)
                    valueList[-1].append(record.find("wml2:value",
                                                     namespaces=nsm).text)

            cols = []
            col1 = []
            col2 = []
            i = -1
            for var in labelList:
                i += 1
                col1 = timeList[i]
                col2 = valueList[i]
                if first:
                    col1.insert(0, 'DateTime [UTC]')
                    col2.insert(0, var)
                if i < 1:  # Only print DateTimes as first column
                    cols.append(col1)
                cols.append(col2)
            lines = map(None, *cols)
            msgstr = ""
            for line in lines:
                msgstr = msgstr + ','.join(line) + "\n"
            return msgstr

    def __init__(self, iface):
        """Constructor.

        :param iface: An interface instance that will be passed to this class
            which provides the hook by which you can manipulate the QGIS
            application at run time.
        :type iface: QgsInterface
        """
        # Save reference to the QGIS interface
        self.iface = iface
        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)
        # initialize locale
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            'FetchFMIOpen_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)

            if qVersion() > '4.3.3':
                QCoreApplication.installTranslator(self.translator)

        # Declare instance attributes
        self.actions = []
        self.menu = self.tr(u'&FetchFMIOpen')
        # TODO: We are going to let the user set this up in a future iteration
        self.toolbar = self.iface.addToolBar(u'FetchFMIOpen')
        self.toolbar.setObjectName(u'FetchFMIOpen')

    # noinspection PyMethodMayBeStatic
    def tr(self, message):
        """Get the translation for a string using Qt translation API.

        We implement this ourselves since we do not inherit QObject.

        :param message: String for translation.
        :type message: str, QString

        :returns: Translated version of message.
        :rtype: QString
        """
        # noinspection PyTypeChecker,PyArgumentList,PyCallByClass
        return QCoreApplication.translate('FetchFMIOpen', message)

    def add_action(
            self,
            icon_path,
            text,
            callback,
            enabled_flag=True,
            add_to_menu=True,
            add_to_toolbar=True,
            status_tip=None,
            whats_this=None,
            parent=None):
        """Add a toolbar icon to the toolbar.

        :param icon_path: Path to the icon for this action. Can be a resource
            path (e.g. ':/plugins/foo/bar.png') or a normal file system path.
        :type icon_path: str

        :param text: Text that should be shown in menu items for this action.
        :type text: str

        :param callback: Function to be called when the action is triggered.
        :type callback: function

        :param enabled_flag: A flag indicating if the action should be enabled
            by default. Defaults to True.
        :type enabled_flag: bool

        :param add_to_menu: Flag indicating whether the action should also
            be added to the menu. Defaults to True.
        :type add_to_menu: bool

        :param add_to_toolbar: Flag indicating whether the action should also
            be added to the toolbar. Defaults to True.
        :type add_to_toolbar: bool

        :param status_tip: Optional text to show in a popup when mouse pointer
            hovers over the action.
        :type status_tip: str

        :param parent: Parent widget for the new action. Defaults None.
        :type parent: QWidget

        :param whats_this: Optional text to show in the status bar when the
            mouse pointer hovers over the action.

        :returns: The action that was created. Note that the action is also
            added to self.actions list.
        :rtype: QAction
        """

        # Create the dialog (after translation) and keep reference
        self.dlg = FetchFMIOpenDialog()

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)

        if whats_this is not None:
            action.setWhatsThis(whats_this)

        if add_to_toolbar:
            self.toolbar.addAction(action)

        if add_to_menu:
            self.iface.addPluginToMenu(
                self.menu,
                action)

        self.actions.append(action)

        return action

    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""

        icon_path = ':/plugins/FetchFMIOpen/icon.png'
        self.add_action(
            icon_path,
            text=self.tr(u'Fetch FMI open data'),
            callback=self.run,
            parent=self.iface.mainWindow())

        # Connect datatype combox state changed signal
        self.dlg.dataTypeComboBox.currentIndexChanged. \
            connect(self.dataTypeChanged)

        # Connect time step combobox state changed signal
        self.dlg.timeStepComboBox.currentIndexChanged. \
            connect(self.timeStepChanged)

    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        for action in self.actions:
            self.iface.removePluginMenu(
                self.tr(u'&FetchFMIOpen'),
                action)
            self.iface.removeToolBarIcon(action)
        # remove the toolbar
        del self.toolbar

    def run(self):
        """Run method that performs all the real work"""
        # check that only one feature is selected in the target layer
        vlayer = self.iface.activeLayer()
        if vlayer:
            selection = vlayer.selectedFeatures()
            if len(selection) == 1:
                pass
            else:
                QMessageBox.information(self.iface.mainWindow(),
                                        "Error",
                                        "You need to have one (and only one) \
                                        feature selected in a vector layer")
                return
        else:
            QMessageBox.information(self.iface.mainWindow(),
                                    "Not a valid vector layer",
                                    "You need to have one (and only one) \
                                    feature selected in a vector layer")
            return

        varListDay = []
        varListWeather = []
        varListMonthly = []
        varListRadiation = []
        varListSoil = []
        varListSealevel = []
        varListSea = []
        varListRoad = []

        varDictDay = {
            0: 'rrday',
            1: 'tday',
            2: 'tmin',
            3: 'tmax',
            4: 'snow',
            5: 'tg_pt12h_min'
        }

        varDictWeather = {
            0: 'r_1h',
            1: 'ri_10min',
            2: 't2m',
            3: 'ws_10min',
            4: 'wd_10min',
            5: 'wg_10min',
            6: 'rh',
            7: 'td',
            8: 'p_sea',
            9: 'snow_aws',
            10: 'n_man',
            11: 'vis'
        }

        varDictMonthly = {
            0: 'rrmon',
            1: 'tmon'
        }

        varDictRadiation = {
            0: 'glob_1min',
            1: 'lwin_1min',
            2: 'lwout_1min',
            3: 'net_1min',
            4: 'dir_1min',
            5: 'refl_1min',
            6: 'sund_1min',
            7: 'diff_1min'
        }

        varDictSoil = {
            0: 'ts_1h_avg',
            1: 'ms_1h_avg'
        }

        varDictSealevel = {
            0: 'watlev'
        }

        varDictSea = {
            0: 'twater',
            1: 'wavehs',
            2: 'modalwdi',
            3: 'whdd',
            4: 'wtp'
        }

        varDictRoad = {
            0: 'ta',
            1: 'ta_10m_dif',
            2: 'pra_1h_acc',
            3: 'prao_24h_acc',
            4: 'pri',
            5: 'prst1',
            6: 'prclst',
            7: 'trfp',
            8: 'rh',
            9: 'td',
            10: 'tdd',
            11: 'po',
            12: 'pa_10m_dif',
            13: 'ws',
            14: 'wd',
            15: 'wg',
            16: 'vis',
            17: 'wawa2',
            18: 'trs',
            19: 'trs_10min_dif',
            20: 'trg',
            21: 'rscc',
            22: 'rscss',
            23: 'rscif',
            24: 'fc',
            25: 'rswl',
            26: 'rssl',
            27: 'rsil',
            28: 'rshu',
            29: 'sawc',
            30: 'savc'
        }

        feature = selection[0]

        if vlayer.fieldNameIndex('Name') != -1:
            nameStr = feature.attributes()[vlayer.fieldNameIndex('Name')]. \
                encode('utf-8')
        elif vlayer.fieldNameIndex('Nimi') != -1:
            nameStr = feature.attributes()[vlayer.fieldNameIndex('Nimi')]. \
                encode('utf-8')
        else:
            QMessageBox.information(self.iface.mainWindow(),
                                    "Not a valid vector layer",
                                    "Field 'Name' (or 'Nimi') is missing!")
            return

        if vlayer.fieldNameIndex('FMISID') != -1:
            fmisidStr = str(feature.attributes()[vlayer.
                            fieldNameIndex('FMISID')])
        else:
            QMessageBox.information(self.iface.mainWindow(),
                                    "Not a valid vector layer",
                                    "Field 'FMSID' is missing!")
            return

        if vlayer.fieldNameIndex('Groups') != -1:
            ryhmatStr = feature.attributes()[vlayer.fieldNameIndex('Groups')].\
                encode('utf-8')
        elif vlayer.fieldNameIndex('Ryhmat') != -1:
            ryhmatStr = feature.attributes()[vlayer.fieldNameIndex('Ryhmat')].\
                encode('utf-8')
        else:
            ryhmatStr = '-'

        if vlayer.fieldNameIndex('Started') != -1:
            alkaenStr = str(feature.attributes()[vlayer.
                                                 fieldNameIndex('Started')])
        elif vlayer.fieldNameIndex('Alkaen') != -1:
            alkaenStr = str(feature.attributes()[vlayer.
                                                 fieldNameIndex('Alkaen')])
        else:
            alkaenStr = '-'

        if vlayer.fieldNameIndex('Ended') == -1:
            loppuenStr = '-'
        else:
            loppuenStr = str(feature.attributes()[vlayer.
                                                  fieldNameIndex('Ended')])

        if vlayer.fieldNameIndex('region') == -1:
            regionStr = '-'
        else:
            regionStr = str(feature.attributes()[vlayer.
                                                 fieldNameIndex('region')])

        stationStr = "Name: " + nameStr + \
                     "\nFMISID: " + fmisidStr + \
                     "\nGroups: " + ryhmatStr + \
                     "\nStarted: " + alkaenStr + \
                     "\nEnded: " + loppuenStr + \
                     "\nRegion: " + regionStr

        self.dlg.stationInfo.setText(stationStr.decode('utf-8'))
        # show the dialog
        self.dlg.show()
        # Run the dialog event loop
        result = self.dlg.exec_()
        # See if OK was pressed
        if result:
            # Formulate the data request

            # Read the api-key
            apiKey = self.dlg.plainTextEdit.toPlainText()
            # If no api-key is provided throw an error
            if not apiKey:
                QMessageBox.information(
                    self.iface.mainWindow(),
                    "No api-key",
                    "You need to provide a valid api-key. Get one from "
                    "https://ilmatieteenlaitos.fi/"
                    "rekisteroityminen-avoimen-datan-kayttajaksi")
                return
            # Read other parameters based on user selections
            startTimeStr = str(self.dlg.periodStart.date().toPyDate()) + \
                "T00:00:00Z"
            endTimeStr = str(self.dlg.periodEnd.date().toPyDate()) + \
                "T00:00:00Z"
            startDateTime = dt.datetime.strptime(startTimeStr,
                                                 '%Y-%m-%dT%H:%M:%SZ')
            endDateTime = dt.datetime.strptime(endTimeStr,
                                               '%Y-%m-%dT%H:%M:%SZ')
            dataIndex = self.dlg.dataTypeComboBox.currentIndex()
            baseRequest = "http://data.fmi.fi/fmi-apikey/" + \
                          apiKey + \
                          "/wfs?request=getFeature&storedquery_id="

            # Split data requests so that only allowed amount of data is
            # requested at a time"
            varStr = ''
            if dataIndex == 0:  # daily weather data
                self.populateVarListDaily(varListDay)
                baseRequest += "fmi::observations::weather::" \
                    "daily::timevaluepair"
                for item in varListDay:
                    varStr = varStr + varDictDay[item] + ','
                varStr = varStr[:-1]
                timeIntervals = self.divideDuration(startDateTime,
                                                    endDateTime,
                                                    272)
            elif dataIndex == 1:  # instantaneous weather data
                baseRequest += "fmi::observations::weather::timevaluepair"
                self.populateVarListWeather(varListWeather)
                for item in varListWeather:
                    varStr = varStr + varDictWeather[item] + ','
                varStr = varStr[:-1]
                timeIntervals = self.divideDuration(startDateTime,
                                                    endDateTime,
                                                    7)
            elif dataIndex == 2:  # monthly weather data
                baseRequest += "fmi::observations::weather::monthly::" \
                    "timevaluepair"
                self.populateVarListMonthly(varListMonthly)
                for item in varListMonthly:
                    varStr = varStr + varDictMonthly[item] + ','
                varStr = varStr[:-1]
                timeIntervals = self.divideDuration(startDateTime,
                                                    endDateTime,
                                                    1095)
            elif dataIndex == 3:   # solar radiation data
                baseRequest += "fmi::observations::radiation::timevaluepair"
                self.populateVarListRadiation(varListRadiation)
                for item in varListRadiation:
                    varStr = varStr + varDictRadiation[item] + ','
                varStr = varStr[:-1]
                timeIntervals = self.divideDuration(startDateTime,
                                                    endDateTime,
                                                    7)
            elif dataIndex == 4:   # soil data
                baseRequest += "fmi::observations::soil::hourly::timevaluepair"
                self.populateVarListSoil(varListSoil)
                for item in varListSoil:
                    varStr = varStr + varDictSoil[item] + ','
                varStr = varStr[:-1]
                timeIntervals = self.divideDuration(startDateTime,
                                                    endDateTime,
                                                    7)
            elif dataIndex == 5:  # sea water level data
                baseRequest += "fmi::observations::mareograph::timevaluepair"
                self.populateVarListSealevel(varListSealevel)
                for item in varListSealevel:
                    varStr = varStr + varDictSealevel[item] + ','
                varStr = varStr[:-1]
                timeIntervals = self.divideDuration(startDateTime,
                                                    endDateTime,
                                                    7)
            elif dataIndex == 6:  # sea roll data
                baseRequest += "fmi::observations::wave::timevaluepair"
                self.populateVarListSea(varListSea)
                for item in varListSea:
                    varStr = varStr + varDictSea[item] + ','
                varStr = varStr[:-1]
                timeIntervals = self.divideDuration(startDateTime,
                                                    endDateTime,
                                                    7)
            else:  # road data
                baseRequest += "livi::observations::road::timevaluepair"
                self.populateVarListRoad(varListRoad)
                for item in varListRoad:
                    varStr = varStr + varDictRoad[item] + ','
                varStr = varStr[:-1]
                timeIntervals = self.divideDuration(startDateTime,
                                                    endDateTime,
                                                    7)

            # Read the optional time step
            tStepMultInd = self.dlg.timeStepComboBox.currentIndex()
            if tStepMultInd > 0:    # Only use timestep if units are given
                tStepValue = self.dlg.spinBox.value()
                if tStepMultInd == 1:
                    tStepMult = 1
                elif tStepMultInd == 2:
                    tStepMult = 60
                tStepValue *= tStepMult
                baseRequest += "&timestep=" + str(tStepValue)

            paramString = "&parameters=" + varStr
            locationString = "&fmisid=" + fmisidStr
            firstInt = True
            strData = ''
            # Request data from server in pieces
            for ind, interval in enumerate(timeIntervals):
                dataRequest = baseRequest
                startTimeStr = interval.strftime('%Y-%m-%dT%H:%M:%SZ')
                # for all but last interval take a few seconds off from the end
                # time to avoid double values
                if ind != len(timeIntervals) - 2:
                    endTimeStr = (
                        timeIntervals[ind + 1] -
                        dt.timedelta(seconds=10)). \
                            strftime('%Y-%m-%dT%H:%M:%SZ')
                else:
                    endTimeStr = (timeIntervals[ind + 1]). \
                        strftime('%Y-%m-%dT%H:%M:%SZ')
                startString = "&starttime=" + startTimeStr
                endString = "&endtime=" + endTimeStr
                dataRequest = dataRequest + \
                    paramString + \
                    locationString + \
                    startString + \
                    endString
                try:  # Actually try fetching the data
                    strNewData = self.getData(dataRequest, firstInt)
                except ValueError as err:   # Throw error and quit
                    QMessageBox.information(self.iface.mainWindow(),
                                            "Error",
                                            err.message)
                    return
                strData = strData + strNewData
                if len(strNewData) > 0:  # Write label line only once
                    firstInt = False
                # Break before last element in timeIntervals as next item is
                # always needed
                if ind == len(timeIntervals) - 2:
                    break

            # If no data was fetched, give error message and quit
            if len(strData) == 0:
                QMessageBox.information(self.iface.mainWindow(),
                                        "No data",
                                        "No data fetched.")
                return

            # Save data to user specified file
            self.fileDialog = QFileDialog()
            fileName = QFileDialog.getSaveFileName(self.fileDialog,
                                                   "Save File")
            if fileName:
                f = open(fileName, 'w')
                f.write(strData)
                f.close()
