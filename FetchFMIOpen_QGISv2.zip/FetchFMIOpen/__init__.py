# -*- coding: utf-8 -*-
"""
/***************************************************************************
 FetchFMIOpen
                                 A QGIS plugin
 A plugin to fetch observation data from FMI Open Data archive
                             -------------------
        begin                : 2017-08-16
        copyright            : (C) 2017 by Tero Niemi & Teemu Kokkonen/Aalto University
        email                : firstname.lastname@aalto.fi
        git sha              : $Format:%H$
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
 This script initializes the plugin, making it known to QGIS.
"""


# noinspection PyPep8Naming
def classFactory(iface):  # pylint: disable=invalid-name
    """Load FetchFMIOpen class from file FetchFMIOpen.

    :param iface: A QGIS interface instance.
    :type iface: QgsInterface
    """
    #
    from .fetch_fmi_open import FetchFMIOpen
    return FetchFMIOpen(iface)
