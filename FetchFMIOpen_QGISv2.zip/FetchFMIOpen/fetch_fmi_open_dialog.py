# -*- coding: utf-8 -*-
"""
/***************************************************************************
 FetchFMIOpenDialog
                                 A QGIS plugin
 A plugin to fetch observation data from FMI Open Data archive
                             -------------------
        begin                : 2017-08-16
        git sha              : $Format:%H$
        copyright            : (C) 2016-2018 by Tero Niemi & Teemu Kokkonen,
                               Aalto University School of Engineering
        email                : firstname.lastname@aalto.fi

    This file is part of FetchFMIOpen.

    FetchFMIOpen is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    FetchFMIOpen is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with FetchFMIOpen.  If not, see <https://www.gnu.org/licenses/>.

 ***************************************************************************/
"""

import os

from PyQt4 import QtGui, uic, QtCore

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'fetch_fmi_open_dialog_base.ui'))


class FetchFMIOpenDialog(QtGui.QDialog, FORM_CLASS):
    def __init__(self, parent=None):
        """Constructor."""
        super(FetchFMIOpenDialog, self).__init__(parent)
        # Set up the user interface from Designer.
        # After setupUI you can access any designer object by doing
        # self.<objectname>, and you can use autoconnect slots - see
        # http://qt-project.org/doc/qt-4.8/designer-using-a-ui-file.html
        # #widgets-and-dialogs-with-auto-connect
        self.setupUi(self)
        self.periodStart.setDate(QtCore.QDate.currentDate().addDays(-1))
        self.periodEnd.setDate(QtCore.QDate.currentDate())
