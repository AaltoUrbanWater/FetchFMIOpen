# -*- coding: utf-8 -*-
"""
/***************************************************************************
 OpenDataFMI
                                 A QGIS plugin
 A plugin to download meteorological data from FMI open data archive
                             -------------------
        begin                : 2016-02-20
        copyright            : (C) 2016 by Teemu Kokkonen and Tero Niemi, Aalto University School of Engineering
        email                : firstname.lastname@aalto.fi
        git sha              : $Format:%H$
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
 This script initializes the plugin, making it known to QGIS.
"""

def classFactory(iface):
    # load OpenDataFMI class from file OpenDataFMI
    from opendatafmi import OpenDataFMI
    return OpenDataFMI(iface)
