# -*- coding: utf-8 -*-
"""
/***************************************************************************
 OpenDataFMI
                                 A QGIS plugin
 A plugin to download meteorological data from FMI open data archive
                              -------------------
        begin                : 2016-02-20
        git sha              : $Format:%H$
        copyright            : (C) 2016 by Teemu Kokkonen and Tero Niemi, Aalto University School of Engineering
        email                : firstname.lastname@aalto.fi
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/ 
"""
# Import the PyQt and QGIS libraries
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *

import datetime as dt
import urllib, urllib2

# Import etree
import xml.etree.ElementTree as ET

# Initialize Qt resources from file resources.py
import resources_rc
# Import the code for the dialog
from opendatafmidialog import OpenDataFMIDialog
import os.path




class OpenDataFMI:

    def dataTypeChanged(self, i):
        if i == 0:
            self.dlg.groupBoxDaily.setEnabled(True)
            self.dlg.groupBoxWeather.setEnabled(False)
            self.dlg.groupBoxRadiation.setEnabled(False)
            self.dlg.groupBoxMonthly.setEnabled(False)
        elif i == 1: 
            self.dlg.groupBoxWeather.setEnabled(True)
            self.dlg.groupBoxDaily.setEnabled(False)
            self.dlg.groupBoxRadiation.setEnabled(False)
            self.dlg.groupBoxMonthly.setEnabled(False)
        elif i == 2:
            self.dlg.groupBoxMonthly.setEnabled(True)
            self.dlg.groupBoxRadiation.setEnabled(False)
            self.dlg.groupBoxDaily.setEnabled(False)
            self.dlg.groupBoxWeather.setEnabled(False)
        else:
            self.dlg.groupBoxRadiation.setEnabled(True)
            self.dlg.groupBoxDaily.setEnabled(False)
            self.dlg.groupBoxWeather.setEnabled(False)
            self.dlg.groupBoxMonthly.setEnabled(False)



    def populateVarListDaily(self,varListDay):
        if self.dlg.cBoxDayPrecip.isChecked() == True:
            varListDay.append(0)
        if self.dlg.cBoxDayMeanT.isChecked() == True:
            varListDay.append(1)
        if self.dlg.cBoxDayMinT.isChecked() == True:
            varListDay.append(2)
        if self.dlg.cBoxDayMaxT.isChecked() == True:
            varListDay.append(3)
        if self.dlg.cBoxDaySnow.isChecked() == True:
            varListDay.append(4)

    def populateVarListWeather(self,varListWeather):
        if self.dlg.cBoxWeaPrecip1h.isChecked() == True:
            varListWeather.append(0)
        if self.dlg.cBoxWeaPrecipInt.isChecked() == True:
            varListWeather.append(1)
        if self.dlg.cBoxWeaTemp.isChecked() == True:
            varListWeather.append(2)
        if self.dlg.cBoxWeaWind.isChecked() == True:
            varListWeather.append(3)
        if self.dlg.cBoxWeaWindDir.isChecked() == True:
            varListWeather.append(4)
        if self.dlg.cBoxWeaRH.isChecked() == True:
            varListWeather.append(5)
        if self.dlg.cBoxWeaDew.isChecked() == True:
            varListWeather.append(6)
        if self.dlg.cBoxWeaSnow.isChecked() == True:
            varListWeather.append(7)
        if self.dlg.cBoxWeaCloud.isChecked() == True:
            varListWeather.append(8)

    def populateVarListRadiation(self,varListRadiation):
        if self.dlg.cBoxGlobR.isChecked() == True:
            varListRadiation.append(0)
        if self.dlg.cBoxLWIn.isChecked() == True:
            varListRadiation.append(1)
        if self.dlg.cBoxLWOut.isChecked() == True:
            varListRadiation.append(2)
        if self.dlg.cBoxNetR.isChecked() == True:
            varListRadiation.append(3)
    
    def populateVarListMonthly(self,varListMonthly):
        if self.dlg.cBoxRRMon.isChecked() == True:
            varListMonthly.append(0)
        if self.dlg.cBoxTMon.isChecked() == True:
            varListMonthly.append(1)

    def divideDuration(self, start, end, period_in_days):
        intervalBreak = []
        intervalBreak.append(start)
        while True:
            intervalBreak.append(intervalBreak[-1] + dt.timedelta(days=period_in_days))
            if intervalBreak[-1] + dt.timedelta(seconds=10) > end:
                intervalBreak[-1] = end
                break
        return intervalBreak

    def getData(self, dataURL, first):
        nsm = {"wml2": "http://www.opengis.net/waterml/2.0", "wfs": "http://www.opengis.net/wfs/2.0", "om": "http://www.opengis.net/om/2.0", "xlink": "http://www.w3.org/1999/xlink"}       
        try:
#            print dataURL       # DEBUG This prints the data query to Python console in QGIS for easier debugging.
            conts = urllib2.urlopen(dataURL)
        except urllib2.HTTPError as e:
            if (e.code == 400):     # Bad request syntax error 
                errorXML = e.read() # Try reading the reason from the xml structure.
                root = ET.fromstring(errorXML)
                reportText = root[0][0].text    # TJN: I'm not sure if the error is always here...
            else:   # Other errors
                reportText = urllib.urlopen(dataURL).read()  # Just show the web page contents
            raise ValueError(reportText)             
        else:   # Everything is fine 
            contents = conts.read()
            root = ET.fromstring(contents)
            WFSMembers = root.findall(".//wfs:member", namespaces=nsm)
            if (len(WFSMembers) == 0):
                return ''
            timeList = []
            valueList = []
            labelList = []
            for element in WFSMembers:
                timeList.append([])
                valueList.append([])
                obsPropNode = element.find(".//om:observedProperty", namespaces=nsm)
                obsPropURL = obsPropNode.get("{http://www.w3.org/1999/xlink}href")
                obsPropcontents = urllib2.urlopen(obsPropURL).read()
                obsPropRoot = ET.fromstring(obsPropcontents)
                labelNode = obsPropRoot.find("{http://inspire.ec.europa.eu/schemas/omop/2.9}label") 
                labelList.append(labelNode.text)
                measurements = element.findall(".//wml2:MeasurementTVP", namespaces=nsm)
                for record in measurements:
                    timeList[-1].append(record.find("wml2:time", namespaces=nsm).text)
                    valueList[-1].append(record.find("wml2:value", namespaces=nsm).text)
    
            cols = []
            col1 = []
            col2 = []
            i = -1
            for var in labelList:
                i = i + 1
                col1 = timeList[i] 
                col2 = valueList[i] 
                if first:
                    col1.insert(0, var)
                    col2.insert(0, var)
                cols.append(col1)
                cols.append(col2)
            lines = map(None, *cols)
            msgstr = ""
            for line in lines:
                msgstr = msgstr + ','.join(line) + "\n" #this also removes brackets and quotes
            return msgstr
            
    def __init__(self, iface):
        # Save reference to the QGIS interface
        self.iface = iface
        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)
        # initialize locale
        locale = QSettings().value("locale/userLocale")[0:2]
        localePath = os.path.join(self.plugin_dir, 'i18n', 'opendatafmi_{}.qm'.format(locale))

        if os.path.exists(localePath):
            self.translator = QTranslator()
            self.translator.load(localePath)

            if qVersion() > '4.3.3':
                QCoreApplication.installTranslator(self.translator)

        # Create the dialog (after translation) and keep reference
        self.dlg = OpenDataFMIDialog()

    def initGui(self):
        # Create action that will start plugin configuration
        self.action = QAction(
            QIcon(":/plugins/opendatafmi/icon.png"),
            u"Tool to download FMI Open data", self.iface.mainWindow())
        # connect the action to the run method
        self.action.triggered.connect(self.run)

        # Add toolbar button and menu item
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu(u"&OpenDataFMI", self.action)

        # Connet datatype combox state changed signal
        self.dlg.dataTypeComboBox.currentIndexChanged.connect(self.dataTypeChanged)


    def unload(self):
        # Remove the plugin menu item and icon
        self.iface.removePluginMenu(u"&OpenDataFMI", self.action)
        self.iface.removeToolBarIcon(self.action)

    # run method that performs all the real work
    def run(self):
        # check that only one feature is selected in the target layer
        vlayer = self.iface.activeLayer()
        if vlayer:
            selection = vlayer.selectedFeatures()
            if len(selection) == 1:
                pass
            else:
                QMessageBox.information(self.iface.mainWindow(),"Not a valid vector layer", "You need to have one (and only one) feature selected in a vector layer")
                return
        else:
            QMessageBox.information(self.iface.mainWindow(),"Not a valid vector layer", "You need to have one (and only one) feature selected in a vector layer")
            return

        varListDay = []
        varListWeather = []
        varListRadiation = []
        varListMonthly = []
        varDictDay = {
        0 : 'rrday', 
        1 : 'tday', 
        2: 'tmin', 
        3: 'tmax', 
        4: 'snow' 
        }
        varDictWeather = {
        0 : 'r_1h', 
        1 : 'ri_10min', 
        2 : 't2m', 
        3 : 'ws_10min', 
        4 : 'wd_10min', 
        5 : 'rh', 
        6 : 'td', 
        7 : 'snow_aws', 
        8 : 'n_man'
        }
        varDictRadiation = {
        0 : 'GLOB_1MIN', 
        1 : 'LWIN_1MIN', 
        2: 'LWOUT_1MIN', 
        3: 'NET_1MIN' 
        }
        varDictMonthly = {
        0 : 'rrmon',
        1 : 'tmon'        
        }
        feature = selection[0]
        nameStr = feature.attributes()[vlayer.fieldNameIndex('Nimi')].encode('utf-8')

        fmisidStr = str(feature.attributes()[vlayer.fieldNameIndex('FMISID')])

        ryhmatStr = feature.attributes()[vlayer.fieldNameIndex('Ryhmat')].encode('utf-8')
        alkaenStr = str(feature.attributes()[vlayer.fieldNameIndex('Alkaen')])
        stationStr = "Nimi: "+nameStr+"\nFMISID: "+fmisidStr+"\nRyhmat: "+ryhmatStr+"\nAlkaen: "+alkaenStr
        self.dlg.stationInfo.setText(stationStr.decode('utf-8'))    
        

        # show the dialog
        self.dlg.show()
        # Run the dialog event loop
        result = self.dlg.exec_()
        # See if OK was pressed
        if result == 1:
            # Formulate the data request
        
            # Read the api-key
            apiKey = self.dlg.plainTextEdit.toPlainText()
            # If no api-key is provided throw an error
            if not apiKey:
                QMessageBox.information(self.iface.mainWindow(),"No api-key", "You need to provide a valid api-key. Get one from https://ilmatieteenlaitos.fi/rekisteroityminen-avoimen-datan-kayttajaksi")
                return
            # Read other parameters based on user selections
            startTimeStr = str(self.dlg.periodStart.date().toPyDate())+"T00:00:00Z"
            endTimeStr = str(self.dlg.periodEnd.date().toPyDate())+"T00:00:00Z"
            startDateTime = dt.datetime.strptime(startTimeStr,'%Y-%m-%dT%H:%M:%SZ')
            endDateTime = dt.datetime.strptime(endTimeStr,'%Y-%m-%dT%H:%M:%SZ')
            dataIndex = self.dlg.dataTypeComboBox.currentIndex()
            baseRequest = "http://data.fmi.fi/fmi-apikey/" + apiKey + "/wfs?request=getFeature&storedquery_id="
            # Split data requests so that only allowed amount of data is requested at a time
            if dataIndex == 0: # daily data
                self.populateVarListDaily(varListDay)
                baseRequest = baseRequest + "fmi::observations::weather::daily::timevaluepair"
                varStr = ''
                for item in varListDay:
                    varStr = varStr + varDictDay[item] + ','
                varStr = varStr[:-1]
                timeIntervals = self.divideDuration(startDateTime,endDateTime, 272)
            elif dataIndex == 1: # more frequent weather data
                baseRequest = baseRequest + "fmi::observations::weather::timevaluepair"
                self.populateVarListWeather(varListWeather)                
                varStr = ''
                for item in varListWeather:
                    varStr = varStr + varDictWeather[item] + ','
                varStr = varStr[:-1]
                timeIntervals = self.divideDuration(startDateTime,endDateTime, 7)
            elif dataIndex == 2: # monthly data
                baseRequest = baseRequest + "fmi::observations::weather::monthly::timevaluepair"
                self.populateVarListMonthly(varListMonthly)                
                varStr = ''
                for item in varListMonthly:
                    varStr = varStr + varDictMonthly[item] + ','
                varStr = varStr[:-1]
                timeIntervals = self.divideDuration(startDateTime,endDateTime, 1095)
            else:   # radiation data
                baseRequest = baseRequest + "fmi::observations::radiation::timevaluepair"
                self.populateVarListRadiation(varListRadiation)                
                varStr = ''
                for item in varListRadiation:
                    varStr = varStr + varDictRadiation[item] + ','
                varStr = varStr[:-1]
                timeIntervals = self.divideDuration(startDateTime,endDateTime, 7)

            paramString = "&parameters=" + varStr
            locationString = "&fmisid=" + fmisidStr
            firstInt = True
            strData = ''
            # Request data from server in pieces
            for ind, interval in enumerate(timeIntervals):
                dataRequest = baseRequest
                startTimeStr = interval.strftime('%Y-%m-%dT%H:%M:%SZ')
                if ind != len(timeIntervals) - 2: #for all but last interval take a few seconds off from the end time to avoid double values 
                    endTimeStr = (timeIntervals[ind + 1]-dt.timedelta(seconds=10)).strftime('%Y-%m-%dT%H:%M:%SZ')
                else:
                    endTimeStr = (timeIntervals[ind + 1]).strftime('%Y-%m-%dT%H:%M:%SZ')
                startString = "&starttime=" + startTimeStr 
                endString = "&endtime=" + endTimeStr 
                dataRequest = dataRequest + paramString + locationString + startString + endString          
                try: # Actually try fetching the data   
                    strNewData = self.getData(dataRequest,firstInt)
                except ValueError as err:   # Throw and error and quit if unsuccessful
                    QMessageBox.information(self.iface.mainWindow(),"Error", err.message)
                    return
                strData = strData + strNewData
                if len(strNewData) > 0: # Write label line only once
                    firstInt = False
                if ind == len(timeIntervals) - 2: # Break before last element in timeIntervals as next item is always needed
                    break
                    
            # If no data was fetched, give error message and quit       
            if len(strData) == 0:
                QMessageBox.information(self.iface.mainWindow(),"No data", "No data fetched.")
                return
            
            # Save data to user specified file
            self.fileDialog = QFileDialog()
            fileName = QFileDialog.getSaveFileName(self.fileDialog,"Save File")
            if fileName:
                f = open(fileName, 'w')
                f.write(strData)
                f.close()
