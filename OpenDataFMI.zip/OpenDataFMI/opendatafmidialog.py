# -*- coding: utf-8 -*-
"""
/***************************************************************************
 OpenDataFMIDialog
                                 A QGIS plugin
 A plugin to download meteorological data from FMI open data archive
                             -------------------
        begin                : 2016-02-20
        git sha              : $Format:%H$
        copyright            : (C) 2016 by Teemu Kokkonen and Tero Niemi, Aalto University School of Engineering
        email                : firstname.lastname@aalto.fi
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

from PyQt4 import QtCore, QtGui
from ui_opendatafmi import Ui_OpenDataFMI
# create the dialog for zoom to point


class OpenDataFMIDialog(QtGui.QDialog, Ui_OpenDataFMI):
    def __init__(self):
        QtGui.QDialog.__init__(self)
        # Set up the user interface from Designer.
        # After setupUI you can access any designer object by doing
        # self.<objectname>, and you can use autoconnect slots - see
        # http://qt-project.org/doc/qt-4.8/designer-using-a-ui-file.html
        # #widgets-and-dialogs-with-auto-connect
        self.setupUi(self)
